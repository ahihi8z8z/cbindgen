pub mod other;

mod other3 {
    #[path = "other4.rs"]
    mod other4;
}
