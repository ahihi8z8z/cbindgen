#[no_mangle]
pub extern "C" fn C()
{ }

#[no_mangle]
pub extern "C" fn B()
{ }

#[no_mangle]
pub extern "C" fn D()
{ }

#[no_mangle]
pub extern "C" fn A()
{ }
