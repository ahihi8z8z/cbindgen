#[repr(C)]
pub struct dep_struct {
    pub x: u32,
    pub y: f64,
}
