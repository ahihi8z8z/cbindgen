#[repr(C)]
pub struct ExtType {
    pub data: u32,
}

pub const EXT_CONST: i32 = 0;
