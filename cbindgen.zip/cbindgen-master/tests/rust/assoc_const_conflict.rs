#[repr(C)]
struct Foo {}

pub const Foo_FOO: u32 = 42;

impl Foo {
    const FOO: i32 = 0;
}

