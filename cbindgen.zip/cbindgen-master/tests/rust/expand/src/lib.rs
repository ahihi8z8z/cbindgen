#[repr(C)]
struct Foo {

}

#[no_mangle]
pub extern "C" fn root(a: Foo) {
}
