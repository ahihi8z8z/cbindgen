pub const B: u8 = 0;
pub const A: u8 = 0;

#[no_mangle]
pub static D: u8 = 0;
#[no_mangle]
pub static C: u8 = 0;
