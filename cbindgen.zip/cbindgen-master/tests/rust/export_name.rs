#[export_name = "do_the_thing_with_export_name"]
pub extern "C" fn do_the_thing() {
  println!("doing the thing!");
}