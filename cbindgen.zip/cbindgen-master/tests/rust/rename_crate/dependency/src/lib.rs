#[repr(C)]
pub struct Foo {
    x: i32,
}
