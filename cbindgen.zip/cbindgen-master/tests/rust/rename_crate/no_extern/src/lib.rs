#[repr(C)]
pub struct NoExternTy {
    field: u8,
}
