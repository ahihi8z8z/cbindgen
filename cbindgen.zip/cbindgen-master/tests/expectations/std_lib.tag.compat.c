#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

struct Option_i32;

struct Result_i32__String;

struct Vec_String;

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void root(const struct Vec_String *a,
          const struct Option_i32 *b,
          const struct Result_i32__String *c);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
