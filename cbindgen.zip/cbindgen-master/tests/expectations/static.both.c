#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Bar Bar;

typedef struct Foo {

} Foo;

extern const int32_t NUMBER;

extern struct Foo FOO;

extern const struct Bar BAR;

void root(void);
