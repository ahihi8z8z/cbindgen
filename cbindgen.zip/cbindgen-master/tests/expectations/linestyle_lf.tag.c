#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

struct Dummy {
  int32_t x;
  float y;
};

void root(struct Dummy d);
